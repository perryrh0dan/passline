# What's new in Passline

Changelog for passline

## Version 0.4.0
- add functionality to store recovery codes

## Version 0.3.3
- add timestamp to backup.

## Version 0.3.2
- use input to filter item list if there is no exact match

## Version 0.3.1
- increment version indicator

## Version 0.3.0
- Generate Password method generates now password with at least one special character, small character, capital character and number.
- Small bug fixes